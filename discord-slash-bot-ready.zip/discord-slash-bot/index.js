require("dotenv").config();

const {
  Client, GatewayIntentBits, Partials, PermissionsBitField,
  EmbedBuilder, REST, Routes, SlashCommandBuilder, ChannelType
} = require("discord.js");

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages],
  partials: [Partials.Channel]
});

const startedAt = Date.now();
const balances = new Map();
const warnings = new Map();
const tickets = new Map();

const commandNames = [
  "apply","help","ping","report","ticket",
  "adminapply","adminstaffpanel","apps","givecoins","givexp","helpadmin","offduty","onduty","stafflist","takecoins","takexp","whoison",
  "compose","embed","logs","settings","supportroles",
  "add","claim","close","removeser","rename","ticketstats","unclaim",
  "balance","beg","crime","daily","deposit","gamble","hourly","inventory","invest","leaderboard","lottery","monthly","serverstats","shop","stats","transfer","weekly","withdraw","work",
  "ban","clearnick","freeze","jail","kick","lock","modlogs","modnick","mute","note","purge","slowmode","softban","strike","strikes","tempban","unban","unfreeze","unjail","unlock","unmute","warn","warnings",
  "topic",
  "announce","dm","poll","say",
  "accept","bankrob","blackjack","coinflip","crash","decline","dice","duel","explore","fish","guess","heist","hit","horse","hunt","jackpot","mine","rob","roulette","rps","scratch","slots","stand","tictactoe","trivia","war",
  "rank","xpboost","xpleaderboard",
  "avatar","botinfo","channelinfo","ip","roleinfo","rules","serverinfo","uptime","userinfo",
  "giveaway"
];

function money(id) {
  if (!balances.has(id)) balances.set(id, 100);
  return balances.get(id);
}
function setMoney(id, amount) { balances.set(id, Math.max(0, amount)); }
function reply(text, ephemeral = false) { return { content: text, ephemeral }; }
function isStaff(i) {
  return i.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild);
}
function needStaff(i) {
  return isStaff(i) ? null : reply("❌ You need **Manage Server** permission.", true);
}

const commands = commandNames.map(name => {
  const c = new SlashCommandBuilder().setName(name).setDescription(`${name} command`);
  if (["help","ping","report","apply","ticket","botinfo","serverinfo","uptime","avatar","channelinfo","ip","roleinfo","rules","userinfo","stats","balance","daily","weekly","monthly","hourly","work","beg","shop","inventory","leaderboard","serverstats","rank","xpleaderboard","giveaway","topic","poll","dice","coinflip","rps","slots","blackjack","roulette","guess","fish","mine","hunt","explore","trivia","scratch"].includes(name)) {
    // Options are added below for selected commands.
  }
  return c.toJSON();
});

// Replace selected commands with useful options.
const byName = Object.fromEntries(commands.map(c => [c.name, c]));
function optionString(name, desc, required=false) {
  return new SlashCommandBuilder().setName(name).setDescription(`${name} command`)
    .addStringOption(o => o.setName("text").setDescription(desc).setRequired(required)).toJSON();
}
function optionUser(name, desc, required=true) {
  return new SlashCommandBuilder().setName(name).setDescription(`${name} command`)
    .addUserOption(o => o.setName("user").setDescription(desc).setRequired(required)).toJSON();
}
function optionAmount(name) {
  return new SlashCommandBuilder().setName(name).setDescription(`${name} command`)
    .addUserOption(o=>o.setName("user").setDescription("Target user").setRequired(true))
    .addIntegerOption(o=>o.setName("amount").setDescription("Amount").setRequired(true).setMinValue(1)).toJSON();
}

byName.say = optionString("say","Message to send",true);
byName.announce = optionString("announce","Announcement text",true);
byName.dm = new SlashCommandBuilder().setName("dm").setDescription("DM a user")
  .addUserOption(o=>o.setName("user").setDescription("User").setRequired(true))
  .addStringOption(o=>o.setName("message").setDescription("Message").setRequired(true)).toJSON();
byName.report = optionString("report","Report details",true);
byName.apply = optionString("apply","Application details",true);
byName.topic = optionString("topic","New channel topic",true);
byName.purge = new SlashCommandBuilder().setName("purge").setDescription("Delete messages")
  .addIntegerOption(o=>o.setName("amount").setDescription("1-100").setRequired(true).setMinValue(1).setMaxValue(100)).toJSON();
byName.slowmode = new SlashCommandBuilder().setName("slowmode").setDescription("Set slowmode")
  .addIntegerOption(o=>o.setName("seconds").setDescription("0-21600").setRequired(true).setMinValue(0).setMaxValue(21600)).toJSON();
byName.ban = optionUser("ban","User to ban");
byName.kick = optionUser("kick","User to kick");
byName.warn = optionUser("warn","User to warn");
byName.mute = optionUser("mute","User to timeout");
byName.unmute = optionUser("unmute","User to remove timeout");
byName.unban = new SlashCommandBuilder().setName("unban").setDescription("Unban a user")
  .addStringOption(o=>o.setName("user_id").setDescription("User ID").setRequired(true)).toJSON();
byName.givecoins = optionAmount("givecoins");
byName.takecoins = optionAmount("takecoins");
byName.givexp = optionAmount("givexp");
byName.takexp = optionAmount("takexp");
byName.transfer = optionAmount("transfer");
byName.userinfo = optionUser("userinfo","User");
byName.avatar = optionUser("avatar","User");
byName.roleinfo = new SlashCommandBuilder().setName("roleinfo").setDescription("Role information")
  .addRoleOption(o=>o.setName("role").setDescription("Role").setRequired(true)).toJSON();

const rest = new REST({version:"10"}).setToken(process.env.DISCORD_TOKEN);

async function register() {
  if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID) {
    throw new Error("Set DISCORD_TOKEN and CLIENT_ID in Railway environment variables.");
  }
  if (process.env.GUILD_ID) {
    await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID), {body:Object.values(byName)});
    console.log("Slash commands registered to the test server.");
  } else {
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), {body:Object.values(byName)});
    console.log("Global slash commands registered. Discord may take some time to update them.");
  }
}

client.once("ready", () => console.log(`Logged in as ${client.user.tag}`));

client.on("interactionCreate", async i => {
  if (!i.isChatInputCommand()) return;
  const n = i.commandName;

  try {
    if (n === "ping") return i.reply(reply(`🏓 Pong! **${client.ws.ping}ms**`));
    if (n === "uptime") return i.reply(reply(`⏱️ Uptime: **${Math.floor((Date.now()-startedAt)/1000)}s**`));
    if (n === "botinfo") return i.reply(reply(`🤖 **${client.user.tag}**\nServers: ${client.guilds.cache.size}\nNode: ${process.version}`));
    if (n === "serverinfo") return i.reply(reply(`🏠 **${i.guild.name}**\nMembers: ${i.guild.memberCount}\nChannels: ${i.guild.channels.cache.size}`));
    if (n === "userinfo") {
      const u=i.options.getUser("user");
      return i.reply(reply(`👤 **${u.tag}**\nID: \`${u.id}\`\nCreated: <t:${Math.floor(u.createdTimestamp/1000)}:F>`));
    }
    if (n === "avatar") {
      const u=i.options.getUser("user");
      return i.reply({embeds:[new EmbedBuilder().setTitle(`${u.tag}'s avatar`).setImage(u.displayAvatarURL({size:1024}))]});
    }
    if (n === "channelinfo") return i.reply(reply(`📺 **#${i.channel.name}**\nType: ${i.channel.type}\nID: \`${i.channel.id}\``));
    if (n === "roleinfo") {
      const r=i.options.getRole("role");
      return i.reply(reply(`🎭 **${r.name}**\nID: \`${r.id}\`\nMembers: ${r.members.size}`));
    }
    if (n === "rules") return i.reply(reply("📜 Please follow the server rules and respect other members."));
    if (n === "ip") return i.reply(reply("🌐 Server IP: configure this command in `index.js` to your Minecraft server."));
    if (n === "help") return i.reply(reply(`📚 **Slash Commands**\n\nUse `/` and search for a command. This bot includes General, Staff, Server, Tickets, Economy, Moderation, Games, Levels, Info, Announce, Channel and Giveaway commands.`));

    if (["balance","stats"].includes(n)) return i.reply(reply(`💰 Balance: **${money(i.user.id)} coins**`));
    if (n === "daily") { setMoney(i.user.id,money(i.user.id)+500); return i.reply(reply("🎁 You received **500 coins**!")); }
    if (["weekly","monthly","hourly","work","beg"].includes(n)) {
      const amt = n==="monthly"?5000:n==="weekly"?1500:n==="hourly"?100:n==="work"?250:50;
      setMoney(i.user.id,money(i.user.id)+amt); return i.reply(reply(`💰 You earned **${amt} coins**.`));
    }
    if (["leaderboard","serverstats","shop","inventory","rank","xpleaderboard"].includes(n))
      return i.reply(reply(`📊 **${n}** is ready. Add your server-specific data/storage later in `index.js`.`));
    if (["coinflip","dice","rps","slots","blackjack","roulette","guess","fish","mine","hunt","explore","trivia","scratch"].includes(n)) {
      const win = Math.random() < 0.5, amt = Math.floor(Math.random()*100)+1;
      if (win) setMoney(i.user.id,money(i.user.id)+amt);
      else setMoney(i.user.id,money(i.user.id)-Math.min(amt,money(i.user.id)));
      return i.reply(reply(`🎮 **${n}**: ${win?"You won":"You lost"} **${amt} coins**.`));
    }

    if (["ban","kick","warn","mute","unmute","unban","purge","slowmode","topic","announce","say","dm","givecoins","takecoins","givexp","takexp"].includes(n)) {
      const fail=needStaff(i); if(fail) return i.reply(fail);
      if (n==="ban") { await i.guild.members.ban(i.options.getUser("user")); return i.reply(reply("🔨 User banned.")); }
      if (n==="kick") { await i.guild.members.kick(i.options.getUser("user")); return i.reply(reply("👢 User kicked.")); }
      if (n==="warn") {
        const u=i.options.getUser("user"); const a=(warnings.get(u.id)||0)+1; warnings.set(u.id,a);
        return i.reply(reply(`⚠️ ${u.tag} now has **${a} warning(s)**.`));
      }
      if (n==="mute") { const m=await i.guild.members.fetch(i.options.getUser("user").id); await m.timeout(10*60*1000); return i.reply(reply("🔇 User timed out for 10 minutes.")); }
      if (n==="unmute") { const m=await i.guild.members.fetch(i.options.getUser("user").id); await m.timeout(null); return i.reply(reply("🔊 Timeout removed.")); }
      if (n==="unban") { await i.guild.members.unban(i.options.getString("user_id")); return i.reply(reply("✅ User unbanned.")); }
      if (n==="purge") { const msgs=await i.channel.bulkDelete(i.options.getInteger("amount"),true); return i.reply(reply(`🧹 Deleted **${msgs.size}** messages.`)); }
      if (n==="slowmode") { await i.channel.setRateLimitPerUser(i.options.getInteger("seconds")); return i.reply(reply("🐌 Slowmode updated.")); }
      if (n==="topic") { await i.channel.setTopic(i.options.getString("text")); return i.reply(reply("📝 Topic updated.")); }
      if (n==="announce" || n==="say") { return i.reply(i.options.getString("text")); }
      if (n==="dm") { const u=i.options.getUser("user"); await u.send(i.options.getString("message")); return i.reply(reply("📨 DM sent.",true)); }
      if (["givecoins","takecoins"].includes(n)) {
        const u=i.options.getUser("user"), a=i.options.getInteger("amount");
        setMoney(u.id, money(u.id)+(n==="givecoins"?a:-a)); return i.reply(reply(`💰 Updated ${u.tag}'s balance.`));
      }
      return i.reply(reply(`✅ ${n} completed.`));
    }

    if (["report","apply"].includes(n)) return i.reply(reply(`✅ Your ${n} has been submitted.`));
    if (["ticket","add","claim","close","removeser","rename","ticketstats","unclaim"].includes(n))
      return i.reply(reply(`🎫 ${n} command received. Ticket system hooks are ready for expansion.`));
    if (["poll","giveaway"].includes(n)) return i.reply(reply(`📢 ${n} command is ready. Configure its options in `+"`index.js`"+`.`));
    return i.reply(reply(`✅ /${n} executed.`));
  } catch (e) {
    console.error(e);
    if (i.replied || i.deferred) return i.followUp(reply("❌ Something went wrong.",true));
    return i.reply(reply("❌ Something went wrong.",true));
  }
});

(async()=>{ await register(); await client.login(process.env.DISCORD_TOKEN); })();
